<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Buy a T-shirt - Stripe Example</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f7f8fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 380px;
            margin: 60px auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 32px 28px 24px 28px;
        }
        h1 {
            font-size: 1.6rem;
            margin-bottom: 18px;
            color: #32325d;
            text-align: center;
        }
        .product {
            text-align: center;
            margin-bottom: 24px;
        }
        .product img {
            width: 120px;
            margin-bottom: 12px;
            border-radius: 8px;
        }
        .product-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .product-price {
            font-size: 1.2rem;
            color: #635bff;
            font-weight: 700;
            margin-bottom: 10px;
        }
        button {
            width: 100%;
            background: #635bff;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 14px 0;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover, button:focus {
            background: #5046e5;
        }
        .secure {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 18px;
            color: #6b7280;
            font-size: 0.95rem;
        }
        .secure svg {
            margin-right: 6px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Buy a T-shirt</h1>
        <form method="post" action="checkout.php" autocomplete="off">
            <div class="product">
                <img src="https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=400&q=80" alt="T-shirt" />
                <div class="product-title">Classic T-shirt</div>
                <div class="product-price">US$20.00</div>
            </div>
            <button type="submit" aria-label="Pay securely with Stripe">Pay with Stripe</button>
        </form>
        <div class="secure">
            <svg width="18" height="18" fill="none" viewBox="0 0 24 24"><path fill="#635bff" d="M12 2a7 7 0 0 0-7 7v3.09A5.98 5.98 0 0 0 4 17a6 6 0 1 0 12 0c0-1.3-.42-2.5-1.13-3.48V9a7 7 0 0 0-7-7zm0 2a5 5 0 0 1 5 5v3.09c-.32-.06-.66-.09-1-.09s-.68.03-1 .09V9a3 3 0 0 0-6 0v3.09c-.32-.06-.66-.09-1-.09s-.68.03-1 .09V9a5 5 0 0 1 5-5zm0 16a4 4 0 0 1-4-4c0-1.3.84-2.4 2-2.82V13a2 2 0 1 1 4 0v.18c1.16.42 2 1.52 2 2.82a4 4 0 0 1-4 4z"/></svg>
            Secure payment powered by Stripe
        </div>
    </div>
</body>
</html>